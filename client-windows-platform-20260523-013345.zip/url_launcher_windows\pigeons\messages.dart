// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:pigeon/pigeon.dart';

@ConfigurePigeon(
  PigeonOptions(
    dartOut: 'lib/src/messages.g.dart',
    cppOptions: CppOptions(namespace: 'url_launcher_windows'),
    cppHeaderOut: 'windows/messages.g.h',
    cppSourceOut: 'windows/messages.g.cpp',
    copyrightHeader: 'pigeons/copyright.txt',
  ),
)
@HostApi()
abstract class UrlLauncherApi {
  bool canLaunchUrl(String url);
  bool launchUrl(String url);
}
